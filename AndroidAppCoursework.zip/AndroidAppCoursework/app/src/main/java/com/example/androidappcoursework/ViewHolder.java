package com.example.androidappcoursework;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



public class ViewHolder extends RecyclerView.ViewHolder {

    ImageView imageView;

    TextView nameView, timeView, descriptionView, roomView;

    public MyViewHolder(@@NonNull View itemView) {
        super(itemView);
        imageView=itemView.findViewbyId(R.id.imageview);
        nameView=itemView.findViewbyId(R.id.name);
        timeView=itemView.findViewbyId(R.id.time);
        descriptionView=itemView.findViewbyId(R.id.description);
        roomView=itemView.findViewbyId(R.id.room);
    }
}
