package com.example.androidappcoursework;

public class item {

    String name;

    String time;

    String description;

    String room;

    int image;

    public item(String name, String time, String description, String room, int image) {
        this.name = name;
        this.time = time;
        this.description = description;
        this.room = room;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
            }

