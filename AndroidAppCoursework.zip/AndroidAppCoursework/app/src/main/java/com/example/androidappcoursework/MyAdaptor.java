package com.example.androidappcoursework;

import android.content.Context;
import android.view.viewGroup;

import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.NonNull;

public class MyAdaptor{

    ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_event, eventNames);
listView.setAdapter(adapter);

}
