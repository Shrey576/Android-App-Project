package com.example.androidappcoursework;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;


public class ContactUsActivity extends AppCompatActivity {

    private EditText editTextName, editTextEmail, editTextMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextMessage = findViewById(R.id.editTextMessage);
        Button buttonSubmit = findViewById(R.id.buttonSubmit);

        // Set onClickListener for the submit button
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input
                String name = editTextName.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String message = editTextMessage.getText().toString().trim();

                // Validate input (optional)

                // Process form submission (e.g., send email)
                // This part will depend on your specific requirements and implementation.
                // You may use Intent to launch an email client or make an HTTP request to a server.
            }
        });
    }
}
