package com.example.androidappcoursework;


import android.graphics.Color;
//import android.graphics.drawable.Drawable;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.view.Menu;
//import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    CalendarView simpleCalendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView_RecyclerView = findViewbyId(R.id.recyclerview);
        list<item> items = new ArrayList<item>();

        RecyclerView.setLayoutManager(new.LinearLayoutManager) (context:this));
        RecyclerView.setAdaptor(new MyAdaptor(getApplicationContext(), items));

        items.add(new item(name:"Getting a part-time job at university", time: "14:00", description: "find out how to get a part-time job at university through our on-campus opportunities and career support.", room: "Chemistry LT1", R.drawable.a));
        items.add(new item(name: "Learning Independent Skills Seminar", time: "15:00", description: "come to this semiar to learn about support for individual living including budgeting, having a healthy diet and establishing work-life balance", room: "Palmer G10", R.drawable.b));
        items.add(new item(name: "How to get the most out of your degree Workshop", time: "19:00", description: "Looking for Study Advice? Want to try a new sport but worried you don't have enough time? This is for you.", room: "Miller 14", R.drawable.c));
        items.add(new item(name: "Candle Making with your Hall Mentors", time: "14:00", description: "Come down and make some candles with us to get a break from studies and meet some new friends!", room: "Park Lounge" R.drawable.d));




        recycler

        // Your existing calendar setup code
        simpleCalendarView = findViewById(R.id.simpleCalendarView);
        simpleCalendarView.setFocusedMonthDateColor(Color.RED);
        simpleCalendarView.setUnfocusedMonthDateColor(Color.BLUE);
        simpleCalendarView.setSelectedWeekBackgroundColor(Color.RED);
        simpleCalendarView.setWeekSeparatorLineColor(Color.GREEN);

        // New code for event creation functionality
        simpleCalendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // Display the selected date by using a toast
            Toast.makeText(getApplicationContext(), dayOfMonth + "/" + month + "/" + year, Toast.LENGTH_LONG).show();

            // Create an event with the selected date
            String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth + "T09:00:00"; // Assuming event starts at 9 AM
            createCalendarEvent(selectedDate);
        });
    }

    // Method to create a calendar event
    private void createCalendarEvent(String startTime) {
        Intent intent = new Intent(Intent.ACTION_EDIT);
        intent.setType("vnd.android.cursor.item/event");
        intent.putExtra("beginTime", convertToMilliseconds(startTime));
        intent.putExtra("endTime", convertToMilliseconds(startTime) + 10800000); // Assuming event lasts for 3 hours
        intent.putExtra("title", "Your Event Title");
        startActivity(intent);
    }

    // Method to convert date and time to milliseconds
    private long convertToMilliseconds(String dateTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        try {
            Date date = sdf.parse(dateTime);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }
}


/*public class MainActivity extends AppCompatActivity {

    CalendarView simpleCalendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        simpleCalendarView = (CalendarView) findViewById(R.id.simpleCalendarView); // get the reference of CalendarView
        simpleCalendarView.setFocusedMonthDateColor(Color.RED); // set the red color for the dates of  focused month
        simpleCalendarView.setUnfocusedMonthDateColor(Color.BLUE); // set the yellow color for the dates of an unfocused month
        simpleCalendarView.setSelectedWeekBackgroundColor(Color.RED); // red color for the selected week's background
        simpleCalendarView.setWeekSeparatorLineColor(Color.GREEN); // green color for the week separator line
        // perform setOnDateChangeListener event on CalendarView
        simpleCalendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // display the selected date by using a toast
            Toast.makeText(getApplicationContext(), dayOfMonth + "/" + month + "/" + year, Toast.LENGTH_LONG).show();
        });
    }


}*/